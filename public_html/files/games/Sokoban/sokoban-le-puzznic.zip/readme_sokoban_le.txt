
                                Welcome to Sokoban LE
                                 by Adrian Smethurst
                                     August 2015
                                ---------------------


Intro
-----
Welcome to my newest creation for Taito's amazing L System arcade hardware.  This game
is a port of a Spectrum game made in 2006 by a Spanish development team called
Compiler Software.  I've ported the core gameplay and then spiced it up a little for
L System, hence I've decided to call it Sokoban LE (L Edition).  I coded this game up
in about 5-6 weeks during August and September 2015.

The original Spectrum game can be found at the following link :-

http://compiler.speccy.org/index.php?lang=eng&game=sokoban

I've approached the original developers of the game and they're more than happy for me
to release this port of their game.

If you've never played Sokoban before then I'd strongly suggest reading the Wikipedia
entry for it :-

https://en.wikipedia.org/wiki/Sokoban

It's an extremely easy game to play, but a very hard game to master.  If you suffer
from claustrophobia then it might not be wise to play this game as you have to move
around in some very compact levels.


My port of the game includes the following :-

All 99 levels from the original Spectrum game, untouched
Full end-game sequence (pimped up a little from the original Spectrum end-game sequence)
9 graphical styles to choose from (8 from the original + 1 designed by me)
10 amazing AY-3-8910 chip tunes to choose from (the original Spectrum tune + 9 new ones)
200 move undo function (an increase of 100% over the Spectrum version)
Level passwords which are compatible with the Spectrum version of the game
Attract mode which demos the first 45 moves of the first 8 levels of the game
Funky Spectrum-inspired in-game menu to change music/graphics/exit to menu/restart level
Two, well hidden, secret warps that, if found, will mean that you only need to complete 24
 levels to actually finish the game ;-)


My port of the game DOES NOT include the following :-

DLC of any kind whatsoever
In-app-purchases of any kind whatsoever
Any kind of multiplayer capture-the-flag/deathmatch mode crap ;-)



Options
-------
When the game boots it will show an intro screen and then proceed to the main menu.  From
here you can use UP/DOWN on the stick and the FIRE button to choose one of the following
options :-

1) start a new game
2) load a level by entering the level password
3) enter the options screen
4) view the game credits

The menu wraps around from top to bottom and vice versa.

When entering the LOAD LEVEL sub-menu you again use up/down/left/right on the stick to
select one of the 6 password letters and change it.  Letters wrap around from Z to A and
from A to Z.  Holding the stick in the UP or DOWN position will auto-rotate the letter
you are currently on.  Pressing FIRE will submit the password.  If the password is correct
then gameplay will resume on that level.  If the password is incorrect you will have a 
choice of pressing FIRE to try again or pressing P1 START to exit to the main menu.

The level passwords are generated in realtime by an algorithm involving a pseudo random
number generator and are NOT stored in the binary, so don't go thinking you can simply
open the binary with a hex editor and find all the passwords for the levels.  You're going
to have to do this the hard way and actually play the game, I'm afraid ;-)

The OPTIONS sub-menu gives you 4 options to play with :-

1) change graphical style
2) turn move UNDO's on or off
3) turn background graphics on or off
4) change the music track or turn music off completely

Again, just like the main menu, the sub-menu also wraps around from top to bottom and vice
versa.

Pressing the FIRE button on GRAPHIC SET changes the tile set used for the levels. I have
included the original 8 graphical styles and one of my own design, which involves pushing
ROMs into ROM sockets.  I figured us arcade freaks spend a disproportionate amount of time
putting roms into rom sockets so it made sense to extrapolate that into a game!

If you don't like the default music you can change it by pressing FIRE on the MUSIC option.
I have included the original Spectrum tune and 9 others.  Six of the tunes have been taken
directly from the Shock Megademo by the Polish demo coding group ESI.  This is one of the
best demos I've ever seen on the Spectrum and I urge you to watch it (on a real Spectrum
of course!) if you've never seen it before.  I also included an awesome tune by Alone
Coder, which really shows what the AY-3-8910 can do in hands of an expert chip tune coder.
If you prefer to play the game in silence (whilst you concentrate intensely on each and 
every next move) then you can also turn the music off here by selecting NONE.

You can also turn off the move UNDO feature (if you're feeling particularly crazy!) and 
turn off the background graphics, so that only the main game grid is drawn.

Credits
-------
Pressing FIRE on the CREDITS option from the main menu takes you to the credits screen 
which shows you the original development team and my name too!

If there is no input from the player for 21 seconds whilst on the main menu the attract
mode will begin.  This will demo the first 45 moves of the first 8 levels of the game and
will be useful for minimising that horrible screen burn-in which has afflicted so many 
Pac-Man monitors and may also help you to understand how to play the game too ;-)  You
can cancel attract mode and return to the main menu by pushing any direction on the stick
or pressing any button.  After demoing the 45 moves of a level the attract mode will 
return back to the intro screen.  You CANNOT exit the intro screen sequence early, you
must wait until it completes and control is returned to you via the main menu screen.


Playing a level
---------------
When you start a new game you use LEFT/RIGHT/UP/DOWN on the stick to move the robot/push
a box and the FIRE button to undo the last move/box push.  You can undo up to 200 moves/
box pushes but you're going to have to have made a real mess of the level to use that many
undos, quite frankly!

Pressing the P1 START button during gameplay will slide the in-game menu onto the screen.
From here you can use UP/DOWN on the stick and the FIRE button to select.  The menu wraps
around from top to bottom and vice versa, just like the rest of the menus in the game.
You can change graphical styles and music from here (or turn music off completely).  You
can also restart the current level (if you've totally messed it up!) or exit to the main 
menu.  Selecting CONTINUE slides the in-game menu off the screen and continues with the 
current level.


Inserting your own AY-3-8910 music tracks
-----------------------------------------
I've made it extremely easy for end users to replace the ORIGINAL music track with one of
their own choosing.  If you wish to do this then you need to ensure the track you wish to
listen to is no bigger than 8192 bytes in size and is in PT3 format.  This format can be
exported by the excellent Vortex Tracker II Windows application and that can be downloaded
here :-

http://bulba.untergrund.net/vortex_e.htm

If you export your track as a PT3 track from that tracker application and then insert it 
at offset $e000 in the binary it will play instead of the ORIGINAL tune when you select
that tune in the game.




Now that you've obviously read all the readme go and play the game and find those 2 hidden
secret warps!



Greets and thanks
-----------------
Huge thanks go out to the guys at Compiler Software for firstly creating Sokoban for the 
Spectrum and secondly open sourcing it.  Without the source for the game it would have
made my porting job quite a bit harder.

Big thanks go to legendary Spectrum coding God Einar Saukas whose zx7 compression technology
is used extensively throughout this game.

Thanks to ESI for the Shock Megademo, you guys have no idea how much your coding style has
influenced me over the years :-)

Thanks again to ESI, Alone Coder and all other people's music who I've blatantly stolen 
and used in this game.

Many thanks go out to Hurray Banana, ben76 and Sokurah for being my beta testers on this 
project and recommending one or two things which I'll admit I wasn't sure about at first
but when implemented did end up adding to the game

Final thanks go out to Taito for making the L System.  In my opinion it's the single
greatest 8-bit computer EVER made, despite its idiosyncrasies.





